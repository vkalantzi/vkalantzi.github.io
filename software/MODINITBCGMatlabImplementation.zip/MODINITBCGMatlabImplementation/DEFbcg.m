function [X, iter2] = DEFbcg(A, B, X, k, tol, eigenvecs1, eigenvecs2)

% Solves AX=B by deflated, modified INITBConjugate Gradient
% Inputs: A (coefficient matrix)
%         B (right-hand sides)
%         X (initial guess on input)
%         k (blocksize of the seed)
%         tol (tolerance of the seed)
%         eigenvecs1 (number of 'smallest' eigenpairs)
%         eigenvecs2 (number of 'largest' eigenpairs)
%
% Outputs: X (approx solutions on exit)
%          iter (total # of iterations)

[~, s] = size(B);

V = [ ];

if eigenvecs1 ~= 0
   [V1, ~] = eigs(A, eigenvecs1, 'sa');
end

if eigenvecs2 ~= 0
   [V2, ~] = eigs(A, eigenvecs2, 'la');
end

if eigenvecs1 ~= 0 && eigenvecs2 ~= 0
   V = [V1, V2];
elseif eigenvecs1 ~= 0
   V = V1;
elseif eigenvecs2 ~= 0
   V = V2;
end

r_old = B - A*X;
X = X + V*((V'*A*V) \ (V'*r_old));
r_old = r_old - A*V*((V'*A*V) \ (V'*r_old));
r_new = r_old;    


iter = zeros(s/k, 1);
var = 0;

for i=1:k:s
    
   var = var + 1;
   P = r_new(:, i:i+k-1) - V*((V'*A*V) \ (V'*r_new(:, i:i+k-1)));
   l = norm(r_new(:, i));
   q = norm(B(:, i));
   temp1 = r_old(:, i:i+k-1)'*r_old(:, i:i+k-1);

   while (l/q) > tol
    
     iter(var, 1) = iter(var, 1) + 1;
     Ap = A*P;
     pTAp = P'*Ap;
        
     a = pinv(pTAp)*temp1;
     X(:, i:i+k-1) = X(:, i:i+k-1) + P*a;
     r_new(:, i:i+k-1) = r_old(:, i:i+k-1) - Ap*a;
     temp2 = r_new(:, i:i+k-1)'*r_new(:, i:i+k-1);
     b = pinv(temp1)*temp2; 
     P = r_new(:, i:i+k-1) - V*((V'*A*V) \ (V'*A*r_new(:, i:i+k-1))) + P*b;
        
     r_old(:, i:i+k-1) = r_new(:, i:i+k-1);
     l = norm(r_new(:, i));
     temp1 = temp2;
   
   end

end

iter2 = norm(iter, 1);

end





