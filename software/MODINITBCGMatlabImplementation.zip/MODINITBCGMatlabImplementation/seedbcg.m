function [X, iter, time1, time2] = seedbcg(A, B, X, k, tol)

% Solves AX=B by single-seed block Conjugate Gradient
% Inputs: A (coefficient matrix)
%         B (right-hand sides)
%         X (initial guess on input)
%         k (blocksize)
%         tol (tolerance)
%
% Outputs: X (approx solutions on exit)
%          iter2 (total # of iterations)
%          time1 (time spent on bcg phase)
%          time2 (time spent on Galerkin projections)

[~, s] = size(B);
r_old = B - A*X;
r_new = r_old;
d = s/k;
iter = zeros(d, 1);
var = 0;
time1 = 0;
time2 = 0;

for i=1:k:s
   var = var + 1;
   P = r_new(:, i:i+k-1);
   l = norm(r_new(:, i));
   q = norm(B(:, i));       
   temp1 = r_old(:, i:i+k-1)'*r_old(:, i:i+k-1);
   while (l/q) > tol
      tic;     
      Ap = A*P;
      pTAp = P'*Ap;
      galp = P;
      iter(var, 1) = iter(var, 1) + 1;

      a = pinv(pTAp)*temp1;
      X(:, i:i+k-1) = X(:, i:i+k-1) + P*a;
      r_new(:, i:i+k-1) = r_old(:, i:i+k-1) - Ap*a;
      temp2 = r_new(:, i:i+k-1)'*r_new(:, i:i+k-1);
      b = pinv(temp1)*temp2; 
      P = r_new(:, i:i+k-1) + P*b;
        
      l = norm(r_new(:, i));
      r_old(:, i:i+k-1) = r_new(:, i:i+k-1);
      temp1 = temp2;
      time1 = time1 + toc;
      
      tic;
      for j=i+k:k:s
         H = pinv(pTAp)*(galp'*r_new(:, j:j+k-1));
         X(:, j:j+k-1) = X(:,j:j+k-1) + galp*H;
         r_new(:, j:j+k-1) = r_old(:, j:j+k-1) - Ap*H;
         r_old(:, j:j+k-1) = r_new(:, j:j+k-1);
      end
      time2 = time2 + toc;
   end  
end

iter2 = norm(iter, 1);

end