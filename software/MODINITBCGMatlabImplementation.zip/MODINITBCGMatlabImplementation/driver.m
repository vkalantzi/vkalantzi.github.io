%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% About:
% ------
%
% A matlab function that includes various methods to compute the solution of a
% SPD linear system with multiple right-hand sides.
% 
% Available methods include: 1) block Conjugate-Gradient, 2) INIT-BCG, 
% 3) modINIT-BCG, 4) deflated Block Conjugate-Gradient
%
%
% Inputs & Outputs:
% -----------------
% Inputs ->  A: SPD coefficient matrix
%            B: matrix of mrhs
%            X: initial guesses
%
% Outputs -> X: final solution
%
%
% References:
% -----------
%
% [1] D. P. O'Leary, "The block Conjugate-Gradient algorithm and other related 
% methods", Linear Algebra and its Applications, 29, pp. 293-322, 1980
%
% [2] T. Chan and W. Wan, "Analysis of projection methods for solving linear
% systems with multiple right-hand sides", SIAM J. Sci. Comput., 18(6),
% pp. 1968-1721, 1997
%
% [3] V. Kalantzis, C. Bekas, A. Curioni and E. Gallopoulos, "Accelerate
% data uncertainty quantification by solving linear systems with multiple
% right-hand sides", to appear in Numerical Algorithms
%
%
% Last update: 11/03/2013 (USA)
% Contact info: kalantzi@cs.umn.edu
%
% This program is free software; you can redistribute and/or modify it
% for non-commercial purposes. This program is distributed without any
% warranty.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear

% Generate a test matrix
n = 4000; % size
A = sparse(diag(1:n))/n; % Diagonal matrix with entries 1/n, 2/n, ..., 1
seedb = 5;
B = rand(n, 2*seedb); % RHS matrix
X = zeros(n,2*seedb); % initial guesses
tol = 1e-8;

% Check if dimensions agree (A must be square and its size must be
% equal to the number of rows of B)
[n, m] = size(A);
[c, s] = size(B);

if (n~=m)
    error('CG-based methods require a square matrix A');
end

if (n~=c)
    error('The number of rows of the RHS does not equal the number of columns of A');
end

set(0, 'defaultaxesfontsize', 17);

% Print size of A and number of right-hand sides
disp(['Size of matrix A: ', num2str(n)]);
disp(['# of multiple right-hand sides: ', num2str(s)]);

% We are interested in solving only A X(:,seedb+1:2*seedb) = B(:,seedb+1:2*seedb)
% The first seedb RHS are used for obtaining an initial guess

[~, iter_bcg, time_bcg, reshist_bcg, ~, ~, ~]    = bcg(A, B(:,seedb+1:2*seedb), X(:,seedb+1:2*seedb), seedb, tol);
[~, iter2_initbcg, time1_initbcg, time2_initbcg] = initbcg(A, B, X, seedb, seedb, tol, tol);
[~, iter2_modinitbcg, time1_modinitbcg, time2_modinitbcg] = modinitbcg(A, B, X, seedb, seedb, tol/10000, tol);
[~, iter2_defbcg] = DEFbcg(A, B(:,seedb+1:2*seedb), X(:,seedb+1:2*seedb), seedb, tol, 5, 5)

disp(['# of iterations made by each method:']);
disp(['BCG: ', num2str(iter_bcg)]);
disp(['INITBCG: ', num2str(iter2_initbcg(2))]);
disp(['MODINITBCG: ', num2str(iter2_modinitbcg(2))]);
disp(['DEFLATED BCG: ', num2str(iter2_defbcg)]);

















