function [X, iter, time1, time2] = modinitbcg(A, B, X, k, k2, tol1, tol2)

% Solves AX=B by modified INITBConjugate Gradient
% Inputs: A (coefficient matrix)
%         B (right-hand sides)
%         X (initial guess on input)
%         k (blocksize of the seed)
%         k2 (blocksize of the non-seed rhs)
%         tol1 (tolerance of the seed)
%         tol2 (tolerance for the non-seed rhs + for the reprojection)
%
% Outputs: X (approx solutions on exit)
%          iter2 (total # of iterations)
%          time1 (time spent on cg phase)
%          time2 (time spent on Galerkin projections)
%
% The following is just for demonstration -- see the FORTRAN 90
% MPI version in my website for an efficient implementation

[~, s] = size(B);
r_old = B - A*X;
temp = X(:, 1:k);
r_new = r_old;
P = r_new(:, 1:k);
gamma_inv = eye(k);
l = norm(r_new(:, 1));
q = norm(B(:, 1));
temp1 = r_old(:, 1:k)'*r_old(:, 1:k);
var = 1;
iter = zeros(1 + (s-k)/k2, 1);
time1 = 0;
time2 = 0;
    
while (l/q) > tol1
   tic;
   iter(var, 1) = iter(var, 1) + 1;
   Ap = A*P;
   pTAp = P'*Ap;
   galp = P;
        
   a = pinv(gamma_inv' * pTAp)*temp1;
   X(:, 1:k) = X(:, 1:k) + P*a;
   r_new(:, 1:k) = r_old(:, 1:k) - Ap*a;
   temp2 = r_new(:, 1:k)'*r_new(:, 1:k); 
   b = gamma_inv * pinv(temp1)*temp2; 
   [P, gamma_inv] = qr(r_new(:, 1:k) + P*b, 0);
        
   temp1 = temp2;
   l = norm(r_new(:, 1));
   r_old(:, 1:k) = r_new(:, 1:k);
   time1 = time1 + toc;
   
   tic;
   H = pinv(pTAp)*(galp'*r_new(:, k+1:s));
   X(:, k+1:s) = X(:, k+1:s) + galp*H;
   r_new(:, k+1:s) = r_new(:, k+1:s) - Ap*H;
   r_old(:, k+1:s) = r_new(:, k+1:s);
   time2 = time2 + toc;
end
    
X(:, 1:k) = temp;
r_old(:, 1:k) = B(:, 1:k) - A*X(:, 1:k);
r_new(:, 1:k) = r_old(:, 1:k);
P = r_new(:, 1:k);
gamma_inv = eye(k);
l = norm(r_new(:, 1));
q = norm(B(:, 1));
temp1 = r_old(:, 1:k)'*r_old(:, 1:k);
   
while (l/q) > tol2
   tic;
   iter(var, 1) = iter(var, 1) + 1;     
   Ap = A*P;
   pTAp = P'*Ap;
   galp = P;
        
   a = pinv(gamma_inv' * pTAp)*temp1;
   X(:, 1:k) = X(:, 1:k) + P*a;
   r_new(:, 1:k) = r_old(:, 1:k) - Ap*a;
   temp2 = r_new(:, 1:k)' * r_new(:, 1:k); 
   b = gamma_inv * pinv(temp1) * temp2; 
   [P, gamma_inv] = qr(r_new(:, 1:k) + P*b, 0);
        
   temp1 = temp2;
   l = norm(r_new(:, 1));
   r_old(:, 1:k) = r_new(:, 1:k);
   time1 = time1 + toc;
   
   tic;
   H = pinv(pTAp)*(galp'*r_new(:, k+1:s));
   X(:, k+1:s) = X(:, k+1:s) + galp*H;
   r_new(:, k+1:s) = r_new(:, k+1:s) - Ap*H;
   r_old(:, k+1:s) = r_new(:, k+1:s);
   time2 = time2 + toc;
end
    
for i=k+1:k2:s
   var = var + 1;
   P = r_new(:, i:i+k2-1);
   l = norm(r_new(:, i));
   q = norm(B(:, i));
   temp1 = r_old(:, i:i+k2-1)'*r_old(:, i:i+k2-1);
       
   while (l/q) > tol2
      tic;
      Ap = A*P;
      pTAp = P'*Ap;
      iter(var, 1) = iter(var, 1) + 1;

      a = pinv(pTAp)*temp1;
      X(:, i:i+k2-1) = X(:, i:i+k2-1) + P*a;
      r_new(:, i:i+k2-1) = r_old(:, i:i+k2-1) - Ap*a;
      temp2 = r_new(:, i:i+k2-1)'*r_new(:, i:i+k2-1);
      b = pinv(temp1)*temp2; 
      P = r_new(:, i:i+k2-1) + P*b;
         
      l = norm(r_new(:, i));
      r_old(:, i:i+k2-1) = r_new(:, i:i+k2-1);
      temp1 = temp2;
      time1 = time1 + toc;
   end  
end

iter2 = norm(iter, 1);

end
