function x1b = galproj(x1b, res1b, k, s, Ps, APs, PAPs)
% Apply galproj to obtain a good initial approximation
% Inputs: x1b (initial approximation)
%         res1b (initial residual)
%         k (# of direction blocks)
%         s (number of columns of each direction block)
%
% Outputs: x1b (updated initial approximation)

for i = k:-1:1
   x1b = x1b + Ps(:,(i-1)*s+1:i*s) * (PAPs(:,(i-1)*s+1:i*s) \ (Ps(:,(i-1)*s+1:i*s)'*res1b) );
   res1b = res1b - APs(:,(i-1)*s+1:i*s) * (PAPs(:,(i-1)*s+1:i*s) \ (Ps(:,(i-1)*s+1:i*s)'*res1b) );
end

end
