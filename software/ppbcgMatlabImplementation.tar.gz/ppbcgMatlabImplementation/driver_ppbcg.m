%! This software is part of the original source files used in the paper                                                                                                                                      
%! "A Scalable Dense Linear System Solver for Multiple Right-Hand Sides in Data Analytics"                                                                                                                   
%! written by V. Kalantzis, C. Malossi, C. Bekas, A. Curioni, E. Gallopoulos, and Y. Saad.                                                                                                                   
%!                                                                                                                                                                                                           
%! This software is free; you can redistribute it and/or modify it under                                                                                                                                     
%! the terms of the GNU Lesser General Public License as published by the                                                                                                                                    
%! Free Software Foundation; either version 2.1 of the License, or (at                                                                                                                                       
%! your option) any later version.                                                                                                                                                                           
%!                                                                                                                                                                                                           
%! The present software is distributed in the hope that it will be useful,                                                                                                                                   
%! but WITHOUT ANY WARRANTY; without even the implied warranty of                                                                                                                                            
%! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser                                                                                                                                   
%! General Public License for more details.                                                                                                                                                                  
%!                                                                                                                                                                                                           
%! You should have received a copy of the GNU Lesser General                                                                                                                                                 
%! Public License along with this library; if not, write to                                                                                                                                                  
%! the Free Software Foundation, Inc., 51 Franklin St, Fifth                                                                                                                                                 
%! Floor, Boston, MA  02110-1301  USA               

clear;

n = 1024; % matrix size
aa = 0.8; % covariance matrix parameters
bb = 2;   %            >>
A = generateModelCovariance(n, aa, bb); % generate test covariance matrix
s = 14;         % # of rhs to generate the subspace -- aka seedb1
B = rand(n, s); % generate test rhs matrix

% run bcg to obtain the deflation subspace
[~, k, ~, ~, Ps, APs, PAPs] = bcg(A, B, zeros(length(A), s), s, 1e-12);

% now generate a new set of rhs and apply galproj
s2 = 2; % s can be different than s
R   = rand(n,s2);
x1b = zeros(n,s2);
% obtain initial guess
initguess = galproj(x1b, R, k, s, Ps, APs, PAPs);

% solve by bcg
[X_ppbcg, iter_ppbcg, ~, reshist_ppbcg, ~, ~, ~] = bcg(A, R, initguess, s2, 1e-8);

% solve by bcg using zeros as the initial solution approximation
[X_bcg, iter_bcg, ~, reshist_bcg, ~, ~, ~] = bcg(A, R, zeros(n,s2), s2, 1e-8);



