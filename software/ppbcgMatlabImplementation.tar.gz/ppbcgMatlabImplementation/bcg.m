function [X, iter2, time, reshist, Ps, APs, PAPs] = bcg(A, B, X, k, tol)
% Solves AX = B by block Conjugate Gradient
% Inputs: A (coefficient matrix)
%         B (right-hand sides)
%         X (initial guess on input)
%         tol (tolerance)
%
% Outputs: X (approx solutions on exit)
%          iter2 (total # of iterations)
%          time1 (time spent on bcg phase)

[~, s] = size(B);
r_old = B - A*X;
r_new = r_old;
iter = zeros(floor(s/k), 1);
var = 0;
time = 0;
reshist = [];
Ps = []; APs = []; PAPs = [];

for i=1:k:s
   var = var + 1;
   P = r_new(:, i:i+k-1);
   l = norm(r_new(:, i));
   q = norm(B(:, i));
   temp1 = r_old(:, i:i+k-1)'*r_old(:, i:i+k-1);
   
   reshist = [l/q];
   while (l/q) > tol
      tic;
      Ap = A*P; APs = [APs, Ap]; Ps = [Ps, P];
      pTAp = P'*Ap; PAPs = [PAPs, pTAp];
      iter(var, 1) = iter(var, 1) + 1;

      a = pinv(pTAp)*temp1;
      X(:, i:i+k-1) = X(:, i:i+k-1) + P*a;
      r_new(:, i:i+k-1) = r_old(:, i:i+k-1) - Ap*a;
      temp2 = r_new(:, i:i+k-1)'*r_new(:, i:i+k-1);
      b = pinv(temp1)*temp2; 
      P = r_new(:, i:i+k-1) + P*b;
         
      r_old(:, i:i+k-1) = r_new(:, i:i+k-1);
      l = norm(r_new(:, i));
      reshist = [reshist;l];
      temp1 = temp2;
      time = time + toc;
   end
end

iter2 = norm(iter, 1);

end
