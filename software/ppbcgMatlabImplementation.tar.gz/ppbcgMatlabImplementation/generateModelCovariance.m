function A = generateModelCovariance(n, a, b)

% Generates a model covariance matrix.
% Warning: A is dense!
% n: size, a: diagonal factor, b: damping factor
A = zeros(n);

for i=1:n
    for j=1:n
       if j == i
          A(i,i) = 1 + i^a;
       else
          A(i,j) = 1/abs(i-j)^b;
       end
    end
end


end





