% lanbd1sv -- Lanczos bidiagonalization for computing 1 leading singular value.
%
%   Synopsis:
%     s = lanbd1sv(A);
%     s = lanbd1sv(A, b);
%     s = lanbd1sv(A, b, tol);
%     [s, resid, steps] = lanbd1sv(...)
%
%   Description:
%     This code computes the leading singular value of A via the Lanczos
%     bidiagonalization process.  It is good for one singular value only.  For
%     multiple singular values, see lanbd().
%
%     The starting vector b is an optional argument.  If not supplied, it will
%     be generated randomly.  The convergence tolerance (on the residual) is
%     also optional and defaults to 1e-10.
%
%     If desired, the routine also returns the residual norm of the leading
%     Ritz triplet and the number of Lanczos steps taken.

function [s, resid, k] = lanbd1sv(A, b, tol)
	if ((nargin < 2) || isempty(b))
		b = randn(size(A, 2), 1);
	end

	if ((nargin < 3) || isempty(tol))
		tol = 1e-10;
	end

	alph = zeros(256, 1);
	beta = zeros(256, 1);
	B = zeros(256, 256);

	k = 1;
	s = 0;
	sp = 0;
	rd = Inf;
	beta(1) = 1;
	p = b/norm(b);
	r = zeros(size(A, 1), 1);
	while (rd > tol)
		k = k + 1;
		sp = s;

		r = A*p - beta(k - 1)*r;
		alph(k - 1) = norm(r);
		r = r/alph(k - 1);
		p = A'*r - alph(k - 1)*p;
		beta(k) = norm(p);
		p = p/beta(k);

		B(k - 1, k - 1) = alph(k - 1);
		if (k >= 3)
			B(k - 2, k - 1) = beta(k - 1);
		end
		[U, S, ~] = svd(B(1:(k - 1), 1:(k - 1)));
		s = S(1);
		resid = abs(beta(k)*U(end, 1));
		rd = abs((s - sp)/sp);
	end

	steps = k;
end
