% isscalarinteger -- See if a variable holds a scalar integer value.
%
%   Synopsis:
%     b = isscalarinteger(x)
%
%   Description:
%     Returns true if x is a scalar integer and false otherwise.

function b = isscalarinteger(x)
	b = isnumeric(x) && isscalar(x) && (x == round(x));
end
