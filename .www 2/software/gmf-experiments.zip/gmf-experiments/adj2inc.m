function E = adj2inc(A)
%
% The function AdIn transforms the adjacency matrix of the graph into his
% incidence matrix.
%
M = nnz(triu(A));
% N = length(A);
[i,j] = find(triu(A));
ic = [i,j]';
je = reshape(ic,1,[]);
ie = (1:M)';
ie = reshape([ie,ie]',1,[]);
s  =  -(-1) .^ (1:length(je));
E = sparse(je,ie,s);
