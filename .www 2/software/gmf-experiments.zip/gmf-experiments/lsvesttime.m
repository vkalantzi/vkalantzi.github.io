% lsvesttime.m -- Compute times needed to estimate the leading singular values.

function lsvesttime()
	generate_all_data();
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function generate_all_data()
	data.mats = {'SNAP/soc-Slashdot0902'
	             'SNAP/amazon0302'
	             'SNAP/web-Stanford'
	             'SNAP/web-NotreDame'
	             'SNAP/amazon0312'
	             'SNAP/amazon0505'
	             'SNAP/amazon0601'
	             'SNAP/web-BerkStan'
	             'SNAP/web-Google',
	             'SNAP/ca-HepTh',
	             'Newman/as-22july06'
	             'Gleich/usroads-48',
	             'SNAP/as-Skitter',
	             'DIMACS10/delaunay_n24'};

	data.type = {'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'i', 'i', 'i', 'i', 'i'};
	data.t = zeros(length(data.mats), 5);
	data.t_avg = zeros(length(data.mats), 1);

	for (i = 1:1:length(data.mats))
		data = do_matrix(data, i);
	end

	save('lsvesttime.mat', 'data');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function data = do_matrix(data, i)
	fprintf('MATRIX:  %s\n', data.mats{i});
	load(['~/work/matrices/ufsparse/mat/' data.mats{i} '.mat']);
	A = Problem.A;
	clear Problem;

	if (data.type{i} == 'i')
		A = adj2inc(A);
	end

	e = ones(size(A, 2), 1);

	[s, resnorm] = lanbd1sv(A, e, 1e-3);

	for (j = 1:1:size(data.t, 2))
		tic();
		[s, resnorm] = lanbd1sv(A, e, 1e-3);
		data.t(i, j) = toc();
	end

	data.t_avg(i) = mean(data.t(i, :));
end
