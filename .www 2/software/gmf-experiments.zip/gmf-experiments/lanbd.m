% lanbd -- Lanczos bidiagonalization for the sparse SVD.
%
%   Synopsis:
%     res = lanbd(A, b);
%     res = lanbd(A, b, opts);
%     res = lanbd(A, b, opts, state);
%
%   Description:
%     This code runs the Lanczos bidiagonalization process on a matrix A with
%     starting vector b.  The behavior of the algorithm may be adjusted by
%     passing an options structure opts with one or more of the following
%     fields set:
%
%       opts.cvgchk       Convergence check for Ritz pairs.
%           'none'   - Do not check convergence (saves computation).
%           'relres' - Relative residual must be at most opts.tol.
%       opts.filter       Filter for filtered Lanczos procedure (see below).
%       opts.filtparams   Parameters for filter (see below).
%       opts.iterfntop    Function called at the top of each iteration.
%       opts.iterfnbot    Function called at the bottom of each iteration.
%       opts.lock         If true, locks converged subspaces on each restart.
%       opts.nsteps       Number of steps before checking for convergence.
%       opts.maxiter      Maximum number of iterations (restarts).
%       opts.orth         Orthogonalization settings.
%           'basic' - No orthogonalization beyond basic Lanczos recurrence.
%           'full'  - Orthogonalize against all previous vectors (a la Arnoldi).
%           'twice' - Same as 'full' but with an extra reorthogonalization step.
%       opts.restart      Restart strategy.
%           'none'     - Unrestarted algorithm.  Each new iteration expands the
%                        existing factorization.
%           'explicit' - Explicitly-restarted algorithm.
%       opts.ritzvecs     If true, computes the Ritz vectors.
%       opts.stop         Stopping criterion.
%           'maxiter' - Run for the maximum number of iterations.
%       opts.tol          Residual tolerance for checking Ritz pair convergence.
%
%     If opts.orth is 'twice' and opts.lock is true, then orthogonalization
%     against the locked vectors will be performed twice.
%
%     Instead of a numeric matrix, A may be a function handle taking two
%     arguments:  a vector v and a string s.  If s is set to 'notransp', the
%     function should compute the action of A on v.  If s is 'transp', it
%     should compute the action of A' on v.
%
%     With one output argument, the function returns a result structure res
%     with the following fields:
%
%       res.QU           Basis for left search space.
%       res.QV           Basis for right search space.
%       res.alph         Diagonal elements of the bidiagonal matrix.
%       res.beta         Superdiagonal elements of the bidiagonal matrix.
%       res.B            Bidiagonal matrix.
%       res.UB           Left singular vectors of B.
%       res.VB           Right singular vectors of B.
%       res.U            (All) left Ritz vectors.
%       res.V            (All) right Ritz vectors.
%       res.S            (All) Ritz values (singular values of B).
%       res.Sf           Un-transformed filtered Ritz values.
%       res.residF       Forward residuals for each Ritz triplet.
%       res.residA       Adjoint residuals of converged Ritz triplets.
%	res.UL           Locked (converged) left Ritz vectors.
%	res.VL           Locked (converged) right Ritz vectors.
%	res.SL           Locked (converged) Ritz values.
%	res.residFL      Forward residuals for locked Ritz triplets.
%	res.residAL      Adjoint residuals for locked Ritz triplets.
%       res.cvgind       Index of converged Ritz triplets.
%       res.converged    True if the convergence (stopping) criterion was met.
%       res.niter        Number of iterations (restarts).
%
%     The Ritz values in res.S and res.SL will be back-transformed to Ritz
%     values for A if a filter was applied.  The filtered Ritz values are
%     available in res.Sf.
%
%     The optional state input allows one to re-run the algorithm starting
%     where it left off, possibly with different options set.  The state
%     structure should contain the QU, QV, alph, and beta outputs of the
%     algorithm, stored in fields with those names.  Optionally, it can contain
%     the UL, VL, SL, residFL, and residAL fields to force purging against a
%     locked subspace.  (Of these, only the UL and VL fields are actually used
%     at this time.) Other fields are ignored.  In particular, one can use the
%     res structure returned from the routine for this purpose.
%
%   Filters:
%     The following filters (values for opts.filter) are recognized:
%
%       'chebab'     L^2 Chebyshev filter for subinterval [a, b] of [0, 1].
%           params.dom - 2-element vector specifying [a, b].
%           params.d   - Degree of expansion to use.  Must be odd.
%
%           For this filter to be useful, the matrix A must be rescaled so that
%           its singular values lie in [0, 1].  Enabling this filter DOES NOT
%           cause this rescaling to happen automatically.
%
%       'chebpoly'   Chebyshev polynomial filter.
%           params.d   - Degree of polynomial to use.  Must be odd.
%
%           This filter is for computing largest singular values.  The matrix A
%           must be rescaled so that the singular values of interest lie in
%           [1, Inf), while the unwanted small ones lie in [0, 1).  Enabling
%           this filter DOES NOT cause this rescaling to happen automatically.
%
%       'none'       No filter.
%           This is the default.  opts.filtparams is ignored.

function varargout = lanbd(varargin)
	[A, Afilt, Nr, Nc, b, opts, QU, QV, alph, beta, UL, SL, VL, residFL, residAL] = parseInputs(varargin{:});
	clear varargin;

	% Convergence / restart loop.
	converged = false;
	for (n = 1:1:opts.maxiter)
		if (~isempty(opts.iterfntop))
			opts.iterfntop(n);
		end

		% Expand the factorization by opts.nsteps.
		[QU, QV, alph, beta] = lanbdCore(Afilt, Nr, Nc, b, opts, QU, QV, UL, VL, alph, beta);

		% Compute the Ritz values and vectors.
		if (length(alph) == 1)
			B = alph(1);
		else
			B = spdiags([alph [0 ; beta(1:end-1)]], [0 1], length(alph), length(alph));
		end
		[UB, S, VB] = svd(full(B));
		S = diag(S);
		if (opts.ritzvecs)
			U = QU(:, 1:end-1)*UB;
			V = QV(:, 1:end-1)*VB;
		else
			U = [];
			V = [];
		end

		% Back-transform Ritz values if a filter was applied.
		Sf = [];
		if (~strcmp(opts.filter, 'none'))
			Sf = S;

			if (opts.ritzvecs)
				for (i = 1:1:length(S))
					S(i) = U(:, i)'*(A(V(:, i), 'notransp'));
					if (S(i) < 0)
						S(i) = -S(i);
						U(:, i) = -U(:, i);
					end
				end
			end
		end

		% Mark Ritz triplets that converged on this iteration.
		if (~isempty(opts.cvgchk))
			cvgind = false(length(S), 1);
			residF = zeros(length(S), 1);
			residA = zeros(length(S), 1);
			for (i = 1:1:length(S))
				[cvgind(i), residF(i), residA(i)] = opts.cvgchk(A, U(:, i), V(:, i), S(i), opts.tol);
			end
		else
			cvgind = [];
			residF = [];
			residA = [];
		end

		% Lock converged Ritz triplets.
		if (opts.lock)
			UL = [UL U(:, cvgind)];
			VL = [VL V(:, cvgind)];
			SL = [SL ; S(cvgind)];
			residFL = [residFL ; residF(cvgind)];
			residAL = [residAL ; residA(cvgind)];
		end

		% Check for convergence.
		if (strcmp(opts.stop, 'maxiter'))
			converged = n == opts.maxiter;
		end

		% Terminate if we've converged.  Otherwise, restart.
		if (converged)
			break;
		end

		switch (opts.restart)
		case 'explicit'
			% Orthogonalize b against the converged subspace.
			npurgeit = 1;
			if (strcmp(opts.orth, 'twice'))
				npurgeit = 2;
			end

			for (j = 1:1:npurgeit)
				for (i = find(cvgind).')
					vi = V(:, i);
					b = b - (v'*b)*vi;
				end
				b = b/norm(b);
			end

			% Throw away the existing factorization.
			QU = NaN(Nr, 1);
			QV = b/norm(b);
			alph = [];
			beta = [];
		case 'none'
			;
		otherwise
			% Should not be able to reach here.
			error('Invalid value for option ''restart''.');
		end

		if (~isempty(opts.iterfnbot))
			opts.iterfnbot(n);
		end
	end

	% Create the output structure.
	res.QU = QU;
	res.QV = QV;
	res.alph = alph;
	res.beta = beta;
	res.B = B;
	res.UB = UB;
	res.VB = VB;
	res.U = U;
	res.V = V;
	res.S = S;
	res.Sf = Sf;
	res.residF = residF;
	res.residA = residA;
	res.UL = UL;
	res.VL = VL;
	res.SL = SL;
	res.residFL = residFL;
	res.residAL = residAL;
	res.cvgind = cvgind;
	res.converged = converged;
	res.niter = n;
	varargout = {res};
end

function [QU, QV, alph, beta] = lanbdCore(A, Nr, Nc, b, opts, QU, QV, UL, VL, alph, beta)
	% Current subspace size.
	ns = size(QV, 2);

	% Don't take more steps than we have dimensions of the matrix.
	steps = min(max(Nr, Nc), opts.nsteps);

	% Number of times to orthogonalize when purging.
	npurgeit = 1;
	if (strcmp(opts.orth, 'twice'))
		npurgeit = 2;
	end

	% Allocate memory.
	QU = [QU zeros(Nr, steps)];
	QV = [QV zeros(Nc, steps)];
	alph = [alph ; zeros(steps, 1)];
	beta = [beta ; zeros(steps, 1)];

	% Lanczos bidiagonalization loop.
	q = QV(:, ns);
	for (k = (ns + 1):1:(ns + steps))
		% Compute the next column of U.
		q = A(q, 'notransp');

		% Purge components from the locked subspace.
		for (j = 1:1:npurgeit)
			for (i = 1:1:size(UL, 2))
				uli = UL(:, i);
				q = q - (uli'*q)*uli;
			end
		end

		% Orthogonalize.
		if (strcmp(opts.orth, 'basic'))
			if (k >= 3)
				q = q - beta(k - 2)*QU(:, k - 2);
			end
		elseif (any(strcmp(opts.orth, {'full', 'twice'})))
			for (i = 1:1:(k - 2))
				qui = QU(:, i);
				q = q - (qui'*q)*qui;
			end
		end

		% Normalize.
		alph(k - 1) = norm(q);
		q = q/alph(k - 1);

		% Reorthogonalize.
		if (strcmp(opts.orth, 'twice'))
			for (i = 1:1:(k - 2))
				qui = QU(:, i);
				q = q - (qui'*q)*qui;
			end
			q = q/norm(q);
		end

		QU(:, k - 1) = q;

		% Compute the next column of V.
		q = A(q, 'transp');

		% Purge components from the locked subspace.
		for (j = 1:1:npurgeit)
			for (i = 1:1:size(VL, 2))
				vli = VL(:, i);
				q = q - (vli'*q)*vli;
			end
		end

		% Orthogonalize.
		if (strcmp(opts.orth, 'basic'))
			if (k >= 2)
				q = q - alph(k - 1)*QV(:, k - 1);
			end
		elseif (any(strcmp(opts.orth, {'full', 'twice'})))
			for (i = 1:1:(k - 1))
				qvi = QV(:, i);
				q = q - (qvi'*q)*qvi;
			end
		end

		% Normalize.
		beta(k - 1) = norm(q);
		q = q/beta(k - 1);

		% Reorthogonalize.
		if (strcmp(opts.orth, 'twice'))
			for (i = 1:1:(k - 1))
				qvi = QV(:, i);
				q = q - (qvi'*q)*qvi;
			end
			q = q/norm(q);
		end

		QV(:, k) = q;
	end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [residF, residA] = computeResiduals(A, u, v, s)
	residF = norm(A(v, 'notransp') - s*u);
	residA = norm(A(u, 'transp') - s*v);
end

function [cvg, residF, residA] = cvgCheckRelRes(A, u, v, s, tol)
	[residF, residA] = computeResiduals(A, u, v, s);
	if (max(residF, residA)/s < tol)
		cvg = true;
	else
		cvg = false;
	end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [A, Afilt, Nr, Nc, b, opts, QU, QV, alph, beta, UL, SL, VL, residFL, residAL] = parseInputs(A, b, userOpts, state)
	if (isnumeric(A))
		[Nr, Nc] = size(A);
		A = @(v, s) applyA(A, v, s);
	else
		% TODO:  Implement this once we've decided the right way to
		% supply the matrix size.
		error('Matrix-free mode is not yet implemented.');
	end

	opts = defaultOptions();
	if ((nargin >= 3) && ~isempty(userOpts))
		checkUserOpts(userOpts);
		opts = mergeOptions(opts, userOpts);
	end
	checkOptsConsistency(opts);

	Afilt = makeAfilt(A, opts);

	if (strcmp(opts.cvgchk, 'none'))
		opts.cvgchk = [];
	elseif (strcmp(opts.cvgchk, 'relres'))
		opts.cvgchk = @cvgCheckRelRes;
	end

	UL = [];
	SL = [];
	VL = [];
	residFL = [];
	residAL = [];

	if ((nargin < 4) || isempty(state))
		QU = NaN(Nr, 1);
		QV = b/norm(b);
		alph = [];
		beta = [];
	else
		QU = state.QU;
		QV = state.QV;
		alph = state.alph;
		beta = state.beta;

		% TODO:  Need to rewrite other code to use state struct so we
		% don't have to unpack this here.

		if (isfield(state, 'UL'))
			UL = state.UL;
		end

		if (isfield(state, 'VL'))
			VL = state.VL;
		end

		if (isfield(state, 'SL'))
			SL = state.SL;
		end

		if (isfield(state, 'residFL'))
			residFL = state.residFL;
		end

		if (isfield(state, 'residAL'))
			residAL = state.residAL;
		end
	end
end

function w = applyA(A, v, s)
	if (strcmp(s, 'notransp'))
		w = A*v;
	elseif (strcmp(s, 'transp'))
		w = A'*v;
	else
		error('s must be ''notransp'' or ''transp''.');
	end
end

function opts = mergeOptions(opts, newOpts)
	for (opt = fieldnames(newOpts).')
		opts.(opt{1}) = newOpts.(opt{1});
	end
end

function checkUserOpts(opts)
	for (opt = fieldnames(opts).')
		opt = opt{1};
		val = opts.(opt);
		switch (opt)
		case 'cvgchk'
			if (~any(strcmp(val, {'relres', 'none'})))
				error('Invalid value for option ''cvgchk''.');
			end
		case 'filter'
			;
		case 'filtparams'
			;
		case 'iterfntop'
			;
		case 'lock'
			;
		case 'nsteps'
			if (~isscalarinteger(val) || (val <= 0))
				error('''nsteps'' option must be a positive integer.')
			end
		case 'maxiter'
			if (~isscalarinteger(val) || (val <= 0))
				error('''maxiter'' option must be a positive integer.')
			end
		case 'orth'
			if (~any(strcmp(val, {'basic', 'full', 'twice'})))
				error('Invalid value for option ''orth''.');
			end
		case 'restart'
			if (~strcmp(val, {'none', 'explicit'}))
				error('Invalid value for option ''restart''.');
			end
		case 'ritzvecs'
			;
		case 'stop'
			if (~strcmp(val, 'maxiter'))
				error('Invalid value for option ''stop''.');
			end
		case 'tol'
			if (val < 0)
				error('''tol'' option must be nonnegative.');
			end
		otherwise
			error(['Bad option ''' opt '''.']);
		end
	end
end

function checkOptsConsistency(opts)
	if (~strcmp(opts.filter, 'none') && ~opts.ritzvecs)
		warning(['With opts.ritzvecs == false, singular values ' ...
			 'not be back-transformed.']);
	end

	if (~strcmp(opts.cvgchk, 'none') && ~opts.ritzvecs)
		error(['Cannot have opts.cvgchk != ''none'' and ' ...
		       'opts.ritzvecs == false.']);
	end

	if (opts.lock && ~opts.ritzvecs)
		error(['Cannot have opts.lock == true and ' ...
		       'opts.ritzvecs == false.']);
	end

	if (~strcmp(opts.restart, 'none') && ~opts.ritzvecs)
		error(['Cannot have opts.restart != ''none'' and ' ...
		       'opts.ritzvecs == false.']);
	end
end

function opts = defaultOptions()
        opts.cvgchk     = 'relres';
	opts.filter     = 'none';
	opts.filtparams = [];
	opts.iterfntop  = [];
	opts.iterfnbot  = [];
	opts.lock       = false;
	opts.nsteps     = 10;
	opts.maxiter    = 1;
	opts.orth       = 'basic';
	opts.restart    = 'none';
	opts.ritzvecs   = true;
	opts.stop       = 'maxiter';
	opts.tol        = 1e-10;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Afilt = makeAfilt(A, opts)
	params = opts.filtparams;
	switch (opts.filter)
	case 'none'
		Afilt = A;
	case 'chebab'
		if (mod(params.d, 2) == 0)
			error('Filter degree must be odd.')
		end

		c = chebabFiltCoeffs(params.dom(1), params.dom(2), params.d);
		Afilt = @(v, s) chebabFiltOp(A, v, c, s);
	case 'chebpoly'
		if (mod(params.d, 2) == 0)
			error('Filter degree must be odd.')
		end

		c = zeros(params.d + 1, 1);
		c(params.d + 1) = 1;
		Afilt = @(v, s) chebabFiltOp(A, v, c, s);
	otherwise
		error('Invalid value for option ''filter''.')
	end
end

function y = chebabFiltOp(A, v, c, str)
	b = c(end)*v;
	s = b;

	for (k = (length(c) - 2):(-2):4)
		if (strcmp(str, 'notransp'))
			b = c(k)*v + 4*(A(A(s, 'notransp'), 'transp')) - b;
		elseif (strcmp(str, 'transp'))
			b = c(k)*v + 4*(A(A(s, 'transp'), 'notransp')) - b;
		else
			error('s must be ''notransp'' or ''transp''.');
		end

		s = b - s;
	end

	if (strcmp(str, 'notransp'))
		b = c(2)*v + 4*(A(A(s, 'notransp'), 'transp')) - b;
		y = A(b - 2*s, 'notransp');
	elseif (strcmp(str, 'transp'))
		b = c(2)*v + 4*(A(A(s, 'transp'), 'notransp')) - b;
		y = A(b - 2*s, 'transp');
	else
		error('s must be ''notransp'' or ''transp''.');
	end
end

function c = chebabFiltCoeffs(a, b, d)
	a = acos(a);
	b = acos(b);

	c = zeros(d + 1, 1);
	c(2:2:end) = 4*(sin((1:2:d)*a) - sin((1:2:d)*b))./((1:2:d)*pi);
end
