% clenshawgmv -- Clenshaw's algorithm for "generalized" mat-vecs.
%
%   Synopsis:
%     y = clenshawgmfmv(A, v, c);
%     y = clenshawgmfmv(A, v, c, str);
%
%   Description:
%     If A = U*S*V' in a singular value decomposition, this function computes
%     the matrix-vector product y = U*p(S)*V'*v, where p is the odd-degree
%     polynomial defined by the Chebyshev series
%
%       p(x) = c(2)*T_1(x) + c(4)*T_3(x) + C(6)*T_5(x) + ...
%
%     If the optional str input is "transp", the product y = V*p(S)*U'*v will
%     be computed instead.
%
%     A may be either a numeric matrix or a function handle with the prototype
%     A(x, s) that computes A*x when the s input is "notransp" and A'*x when
%     the s input is "transp".
%
%   Notes:
%     The coefficient vector c must satisfy c(1:2:end) = 0.

function y = clenshawgmv(A, v, c, str)
	if (isnumeric(A))
		A = @(v, s) applyA(A, v, s);
	end

	if (nargin < 4)
		str = 'notransp';
	end

	b = c(end)*v;
	s = b;

	for (k = (length(c) - 2):(-2):4)
		if (strcmp(str, 'notransp'))
			b = c(k)*v + 4*(A(A(s, 'notransp'), 'transp')) - b;
		elseif (strcmp(str, 'transp'))
			b = c(k)*v + 4*(A(A(s, 'transp'), 'notransp')) - b;
		else
			error('s must be ''notransp'' or ''transp''.');
		end

		s = b - s;
	end

	if (strcmp(str, 'notransp'))
		b = c(2)*v + 4*(A(A(s, 'notransp'), 'transp')) - b;
		y = A(b - 2*s, 'notransp');
	elseif (strcmp(str, 'transp'))
		b = c(2)*v + 4*(A(A(s, 'transp'), 'notransp')) - b;
		y = A(b - 2*s, 'transp');
	else
		error('s must be ''notransp'' or ''transp''.');
	end
end

function w = applyA(A, v, s)
	if (strcmp(s, 'notransp'))
		w = A*v;
	elseif (strcmp(s, 'transp'))
		w = A'*v;
	else
		error('s must be ''notransp'' or ''transp''.');
	end
end
