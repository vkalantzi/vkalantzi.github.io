function rn0092()
	%generate_all_data();
	%load('rn0092.mat');
	%print_all_basic_tables(data);
	%print_tables_all_matrices_fixed_tolerance(data, 3);
	%dump_data_to_dsv(data);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function generate_all_data()
	if (exist('rn0092.mat', 'file'))
		% Load the "data" struct.
		load('rn0092.mat');
	else
		data.mats = {'SNAP/ca-HepTh',
		             'Newman/as-22july06'
			     'Gleich/usroads-48',
			     'SNAP/as-Skitter',
			     'DIMACS10/delaunay_n24'};

		data.f = {@(x, s1) sin(x)
			  @(x, s1) sin(4*x)};

		data.f_str = {'sin(x)',
		              'sin(4x)'};

		data.tol = {[10.^((-3):(-1):(-10))].',
                            [10.^((-3):(-1):(-10))].'};

		data.dmax = {NaN,
		             NaN};

		data.nmax = {100,
			     100};

		data.res = cell(length(data.mats), length(data.f));
		data.sv = cell(length(data.mats), 1);
	end

	for (i = 1:1:length(data.mats))
		data = do_matrix(data, i);
	end

	save('rn0092.mat', 'data');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function data = do_matrix(data, i)
	fprintf('MATRIX:  %s\n', data.mats{i});
	load(['~/work/matrices/ufsparse/mat/' data.mats{i} '.mat']);
	fprintf('Converting adjacency matrix to incidence matrix... ');
	A = adj2inc(Problem.A);
	fprintf('Done.\n');
	fprintf('Incidence matrix is %d x %d.\n', size(A, 1), size(A, 2));
	clear Problem;

	if (isempty(data.sv{i}))
		fprintf('Computing leading 10 singular values... ');
		data.sv{i} = svds(A, 10);
		fprintf('Done.\n');
		save('rn0092.mat', 'data');
	else
		fprintf('Already have leading 10 singular values.\n');
	end

	for (j = 1:1:length(data.f))
		data = do_function_for_matrix(A, data, i, j);
	end
end

function data = do_function_for_matrix(A, data, i, j)
	if (isempty(data.res{i, j}))
		data.res{i, j} = cell(length(data.tol{j}), 1);
		for (k = 1:1:length(data.tol{j}))
			data.res{i, j}{k} = struct(...
			    'pe', struct(), ...
			    'pa', struct(), ...
			    'ld', struct(), ...
			    'lf', struct() ...
			);
		end
	end

	data = do_poly_interp(A, data, i, j, ...
	    @gmf_poly_get_degs_for_tols_interp_approx, ...
	    'pa', '(polynomial interp approx)');
	data = do_lbd_dynamic(A, data, i, j);
	data = do_lbd_fixed(A, data, i, j);
end

function data = do_poly_interp(A, data, i, j, get_deg_fn, fld, hdr)
	tol = data.tol{j};
	s1 = data.sv{i}(1);
	f = @(x) data.f{j}(x, s1);
	dmax = data.dmax{j};

	need_opt_degs = false;
	for (k = 1:1:length(tol))
		if (~isfield(data.res{i, j}{k}.(fld), 'd'))
			need_opt_degs = true;
			break;
		end
	end

	fprintf([data.f_str{j} ' ' hdr '\n']);

	if (need_opt_degs)
		fprintf('Computing optimal degrees... ');
		d = get_deg_fn(A, f, tol, dmax);
		for (k = 1:1:length(tol))
			data.res{i, j}{k}.(fld).d = d(k);
		end
		fprintf('Done.\n');
		save('rn0092.mat', 'data');
	else
		fprintf('Already have optimal degrees.\n');
	end

	fprintf('Tolerance   Answer                    Deg.  Time (s)\n');
	fprintf('----------------------------------------------------\n');
	for (k = 1:1:length(tol))
		d = data.res{i, j}{k}.(fld).d;
		if (~isnan(d) & ~isfield(data.res{i, j}{k}.(fld), 't_avg'))
			[t_avg, r, times, seeds] = time_gmf_poly_interp(A, f, d);
			data.res{i, j}{k}.(fld).r = r(1);
			data.res{i, j}{k}.(fld).times = times;
			data.res{i, j}{k}.(fld).seeds = seeds;
			data.res{i, j}{k}.(fld).t_avg = t_avg;
			save('rn0092.mat', 'data');
		end

		if (~isnan(d))
			r = data.res{i, j}{k}.(fld).r;
			t_avg = data.res{i, j}{k}.(fld).t_avg;
			fprintf('%.1e     %.16e    %2d    %.2f\n', tol(k), r, d, t_avg);
		else
			fprintf('%.1e     ---\n', tol(k));
		end
	end
end

function data = do_lbd_dynamic(A, data, i, j)
	tol = data.tol{j};
	s1 = data.sv{i}(1);
	f = @(x) data.f{j}(x, s1);
	nmax = data.nmax{j};

	need_opt_steps = false;
	for (k = 1:1:length(tol))
		if (~isfield(data.res{i, j}{k}.ld, 'n'))
			need_opt_steps = true;
			break;
		end
	end

	fprintf([data.f_str{j} ' (Lanczos dynamic)\n']);

	if (need_opt_steps)
		fprintf('Computing optimal step counts... ');
		steps = gmf_lbd_get_steps_for_tols(A, f, tol, nmax);
		for (k = 1:1:length(tol))
			data.res{i, j}{k}.ld.n = steps(k);
		end
		fprintf('Done.\n');
		save('rn0092.mat', 'data');
	else
		fprintf('Already have optimal steps.\n');
	end

	fprintf('Tolerance   Answer                    Steps  Time (s)\n');
	fprintf('-----------------------------------------------------\n');
	for (k = 1:1:length(tol))
		n = data.res{i, j}{k}.ld.n;
		if (~isnan(n) && ~isfield(data.res{i, j}{k}.ld, 't_avg'))
			[t_avg, r, n, times, seeds] = time_gmf_lbd(A, f, tol(k), n);
			data.res{i, j}{k}.ld.r = r(1);
			data.res{i, j}{k}.ld.n = n;
			data.res{i, j}{k}.ld.times = times;
			data.res{i, j}{k}.ld.seeds = seeds;
			data.res{i, j}{k}.ld.t_avg = t_avg;
			save('rn0092.mat', 'data');
		else
			n = data.res{i, j}{k}.ld.n;
		end

		if (~isnan(n))
			r = data.res{i, j}{k}.ld.r;
			t = data.res{i, j}{k}.ld.t_avg;
			fprintf('%.1e     %.16e    %2d    %.2f\n', tol(k), r, n, t);
		else
			fprintf('%.1e     ---\n', tol(k));
		end
	end
end

function data = do_lbd_fixed(A, data, i, j)
	tol = data.tol{j};
	s1 = data.sv{i}(1);
	f = @(x) data.f{j}(x, s1);

	fprintf([data.f_str{j} ' (Lanczos fixed)\n']);
	fprintf('Tolerance   Answer                    Steps  Time (s)\n');
	fprintf('-----------------------------------------------------\n');
	for (k = 1:1:length(tol))
		n = data.res{i, j}{k}.ld.n;
		if (~isnan(n) && ~isfield(data.res{i, j}{k}.lf, 't_avg'))
			[t_avg, r, n, times, seeds] = time_gmf_lbd(A, f, 0, n);
			data.res{i, j}{k}.lf.r = r(1);
			data.res{i, j}{k}.lf.n = n;
			data.res{i, j}{k}.lf.times = times;
			data.res{i, j}{k}.lf.seeds = seeds;
			data.res{i, j}{k}.lf.t_avg = t_avg;
			save('rn0092.mat', 'data');
		else
			n = data.res{i, j}{k}.ld.n;
		end

		if (~isnan(n))
			r = data.res{i, j}{k}.lf.r;
			t = data.res{i, j}{k}.lf.t_avg;
			fprintf('%.1e     %.16e    %2d    %.2f\n', tol(k), r, n, t);
		else
			fprintf('%.1e     ---\n', tol(k));
		end
	end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [t_avg, r, times, seeds] = time_gmf_poly_interp(A, f, d)
	Ntrials = 5;

	t_avg = 0;
	times = zeros(Ntrials + 1, 1);
	seeds = cell(Ntrials + 1, 1);
	for (j = 1:1:(Ntrials + 1))
		seeds{j} = rng();

		tic();
		r = gmf_poly_interp(A, f, d);
		times(j) = toc();
	end

	t_avg = mean(times(2:end));
end

function [t_avg, r, n, times, seeds] = time_gmf_lbd(A, f, tol, nmax)
	Ntrials = 5;

	t_avg = 0;
	t = zeros(Ntrials + 1, 1);
	seeds = cell(Ntrials + 1, 1);
	e = ones(size(A, 2), 1);
	for (j = 1:1:(Ntrials + 1))
		seeds{j} = rng();

		tic();
		[r, n] = gmf_lbd(A, e, f, tol, nmax);
		times(j) = toc();
	end

	t_avg = mean(times(2:end));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Approximate f^\diamond(A)e using a degree-d polynomial approximation.
function r = gmf_poly_interp(A, f, d)
	e = ones(size(A, 2), 1);
	[s, resnorm] = lanbd1sv(A, e, 1e-3);
	s = s + resnorm;
	c = chebtech2.vals2coeffs(f(s*chebpts(d + 1)));
	r = clenshawgmv(A/s, e, c, 'notransp');
end

% Approximate f^\diamond(A)e using Lanczos bidiagonalization with full
% orthogonalization, checking for convergence at every step.  Set tol = 0 to
% force the use of exactly maxsteps steps.
function [r, nsteps] = gmf_lbd(A, b, f, tol, maxsteps)
	[Nr, Nc] = size(A);

	nsteps = NaN;
	QU = zeros(Nr, maxsteps + 1);
	QV = zeros(Nc, maxsteps + 1);
	alph = zeros(maxsteps, 1);
	beta = zeros(maxsteps, 1);
	B = zeros(maxsteps, maxsteps + 1);
	r = zeros(size(A, 1), 1);
	rp = zeros(size(A, 1), 1);
	normb = norm(b);

	QV(:, 1) = b/normb;

	q = QV(:, 1);
	for (n = 2:1:(maxsteps + 1))
		% Forward step.
		q = A*q;
		for (i = 1:1:(n - 2))
			qui = QU(:, i);
			q = q - (qui'*q)*qui;
		end
		alph(n - 1) = norm(q);
		q = q/alph(n - 1);
		QU(:, n - 1) = q;

		% Transpose step.
		q = A'*q;
		for (i = 1:1:(n - 1))
			qvi = QV(:, i);
			q = q - (qvi'*q)*qvi;
		end
		beta(n - 1) = norm(q);
		q = q/beta(n - 1);
		QV(:, n) = q;

		% Compute projected approximation.
		if (tol > 0)
			B(n - 1, n - 1) = alph(n - 1);
			B(n - 1, n) = beta(n - 1);
			[U, S, V] = svd(B(1:(n - 1), 1:(n - 1)));
			r = U*(f(diag(S)).*(normb*V(1, :)'));

			% Check convergence.
			if (n > 2)
				rd = norm(r - [rp ; 0], 2)/norm(rp, 2);
				if (rd < tol)
					nsteps = n - 1;
					break;
				end
			end

			rp = r;
		elseif ((tol == 0) && (n == maxsteps + 1))
			B = full(spdiags([alph [0 ; beta(1:(end - 1))]], [0 1], maxsteps, maxsteps));
			[U, S, V] = svd(B(1:(n - 1), 1:(n - 1)));
			r = U*(f(diag(S)).*(normb*V(1, :)'));
			nsteps = maxsteps;
		end
	end

	r = QU(:, 1:(n - 1))*r;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function d = gmf_poly_get_degs_for_tols_interp_approx(A, f, tol, dmax)
	e = ones(size(A, 2), 1);
	[s, resnorm] = lanbd1sv(A, e, 1e-3);
	s = s + resnorm;
	x = linspace(0, 1, 65537).';
	fx = f(s*x);
	norm_f = norm(fx, Inf);

	if (isempty(dmax) || isnan(dmax))
		dmax = length(chebfun(@(x) f(s*x))) - 1;
	end

	i = 1;
	d = NaN(size(tol));
	for (deg = 1:2:dmax)
	        p = chebfun(@(x) f(s*x), deg + 1);
		err = norm(fx - p(x), Inf);
	        while (err < tol(i)*norm_f)
	                d(i) = deg;
	                i = i + 1;
	                if (i > length(tol))
	                        break;
	                end
	        end

		if (i > length(tol))
			break;
		end
	end
end

% Compute relative differences in the evaluation of f^\diamond(A)e by
% polynomial interpolation at each successive degree.  The point of this
% function is to help us assess what degree is needed to achieve a given
% relative tolerance.
function rd = gmf_poly_get_reldiffs_at_degs_interp(A, f, dmax)
	e = ones(size(A, 1), 1);
	[s, resnorm] = lanbd1sv(A, e, 1e-3);
	s = s + resnorm;

	if (isempty(dmax) || isnan(dmax))
		dmax = length(chebfun(@(x) f(s*x))) - 1;
	end

	nmax = (dmax + 1)/2;

	T = gmf_chebpoly(A/s, e, dmax);

	r = [];
	rp = [];
	rd = zeros(nmax, 1);
	for (n = 1:1:nmax)
		d = 2*n - 1;
		c = chebcoeffs(chebfun(@(x) f(s*x), d + 1));
		c = c(2:2:end);

		r = 0;
		for (i = 1:1:length(c))
			r = r + c(i)*T{i};
		end

		if (n > 1)
			rd(n) = norm(r - rp, 2)/norm(rp, 2);
		end
		rp = r;
	end
	rd(1) = Inf;
end

function T = gmf_chebpoly(A, b, dmax)
	nmax = (dmax + 1)/2;
	T = cell(nmax, 1);

	T{1} = A*b;
	T{2} = 4*A*(A'*T{1}) - 3*T{1};
	for (n = 3:1:nmax)
		T{n} = 4*(A*(A'*T{n - 1})) - 2*T{n - 1} - T{n - 2};
	end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function steps = gmf_lbd_get_steps_for_tols(A, f, tol, maxsteps)
        steps = zeros(size(tol));
        rd = gmf_lbd_get_reldiffs_at_steps(A, f, maxsteps);
        for (i = 1:1:length(tol))
                k = find(rd < tol(i), 1, 'first');
                if (isempty(k))
                        steps(i) = NaN;
                else
                        steps(i) = k;
                end
        end
end

% Compute relative differences in the evaluation of f^\diamond(A)e by Lanczos
% bidiagonalization at each Lanczos step.  The point of this function is to
% help us assess how many steps are needed to achieve a given relative
% tolerance.
function rd = gmf_lbd_get_reldiffs_at_steps(A, f, maxsteps)
        e = ones(size(A, 2), 1);
        opts = struct('nsteps', maxsteps, 'maxiter', 1, 'orth', 'full', ...
                      'cvgchk', 'none', 'ritzvecs', false);
        lanf = lanbd(A, e/norm(e), opts);

        r = [];
        rp = [];
        rd = zeros(maxsteps, 1);
        for (k = 1:1:maxsteps)
                [U, S, V] = svd(full(lanf.B(1:k, 1:k)));
                r = lanf.QU(:, 1:k)*(U*(f(S)*(V'*(lanf.QV(:, 1:k)'*e))));
                if (k > 1)
                        rd(k) = norm(r - rp, 2)/norm(rp, 2);
                end
                rp = r;
        end
        rd(1) = Inf;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function print_all_basic_tables(data)
	for (i = 1:1:length(data.mats))
		for (j = 1:1:length(data.f))
			print_basic_table(data, i, j);
		end
	end
end

function print_basic_table(data, i, j)
	fprintf('%s, %s\n', data.mats{i}, data.f_str{j})
	fprintf('           |          Polynomial Approximation          |          Lanczos Bidiagonalization          |         \n');
	fprintf('Tolerance  |  Answer                    Deg.  Time (s)  |  Answer                    Steps  Time (s)  |  Speedup\n');
	fprintf('-----------|--------------------------------------------|---------------------------------------------|---------\n');

	for (k = 1:1:length(data.tol{j}))
		res_p = data.res{i, j}{k}.pa;
		res_l = data.res{i, j}{k}.lf;

		fprintf('%.1e    |', data.tol{j}(k));

		if (~isnan(res_p.d))
			fprintf(' % .16e    %4d   %6.2f   |', res_p.r, res_p.d, res_p.t_avg);
		else
			fprintf('  -----                     ---   -----     |');
		end

		if (~isnan(data.res{i, j}{k}.ld.n))
			fprintf(' % .16e     %4d   %6.2f   |', res_l.r, res_l.n, res_l.t_avg);
		else
			fprintf('  -----                      ---   -----     |');
		end

		if (~isnan(res_p.d) && ~isnan(data.res{i, j}{k}.ld.n))
			fprintf('  %.2f\n', res_l.t_avg/res_p.t_avg);
		else
			fprintf('  ----\n');
		end
	end
	fprintf('\n');
end

function print_tables_all_matrices_fixed_tolerance(data, k)
	for (j = 1:1:length(data.f))
		fprintf([data.f_str{j} '\n']);
		fprintf('                       |    Polynomial    |      Lanczos (Dynamic)     |       Lanczos (Fixed)\n');
		fprintf('Matrix                 |  Deg.  Time (s)  |  Steps  Time (s)  Speedup  |  Steps  Time (s)  Speedup\n');
		fprintf('-----------------------|------------------|----------------------------|----------------------------\n');

		for (i = 1:1:length(data.mats))
			res_p = data.res{i, j}{k}.pa;
			res_ld = data.res{i, j}{k}.ld;
			res_lf = data.res{i, j}{k}.lf;

			fprintf('%-21s  |', data.mats{i});

			if (~isnan(res_p.d))
				fprintf('  %4d   %6.2f   |', res_p.d, res_p.t_avg);
			else
				fprintf('  ---   ----    |');
			end

			if (~isnan(res_ld.n))
				fprintf('  %4d    %6.2f', res_ld.n, res_ld.t_avg);
				if (~isnan(res_p.d))
					fprintf('   %6.2f   |', res_ld.t_avg/res_p.t_avg);
				else
					fprintf('     -----   |');
				end
			else
				fprintf('   ---     -----    -----   |');
			end

			if (~isnan(res_ld.n))
				fprintf('  %4d    %6.2f', res_lf.n, res_lf.t_avg);
				if (~isnan(res_p.d))
					fprintf('    %6.2f\n', res_lf.t_avg/res_p.t_avg);
				else
					fprintf('      -----\n');
				end
			else
				fprintf('   ---     -----     -----\n');
			end
		end
		fprintf('\n');
	end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function dump_data_to_dsv(data)
	Ntrials = 5;

	fout = fopen('rn0092.dsv', 'w');
	if (fout == -1)
		error('Could not open file rn0092.dsv for writing.');
	end

	for (i = 1:1:length(data.mats))
		for (j = 1:1:length(data.f))
			res = data.res{i, j};
			tol = data.tol{j};

			for (k = 1:1:length(tol))
				for (ty = {'pa', 'ld', 'lf'})
					ty = ty{1};
					s = res{k}.(ty);

					n = NaN;
					if (strcmp(ty, 'pa'))
						n = s.d;
					else
						if (isempty(fields(s)))
							n = NaN;
						else
							n = s.n;
						end
					end

					if (isnan(n))
						r = NaN;
						t_avg = NaN;
						times = NaN(Ntrials + 1, 1);
					else
						r = s.r;
						t_avg = s.t_avg;
						times = s.times;
					end

					fprintf(fout, '%s|%s|%.1e|%s|%d|%.16e|', data.mats{i}, data.f_str{j}, tol(k), ty, n, r);

					for (ell = 1:1:length(times))
						fprintf(fout, '%.16e|', times(ell));
					end

					fprintf(fout, '%.16e\n', t_avg);
				end
			end
		end
	end

	fclose(fout);
end
