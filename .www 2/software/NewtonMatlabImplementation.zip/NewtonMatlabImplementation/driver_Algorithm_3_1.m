%=====================================================================
% Some Matlab routines to partially accompany the paper
% "Spectral Schur Complement Techniques for Symmetric 
% Eigenvalue Problems", to appear in ETNA, written by 
% V. Kalantzis, R. Li, and Y. Saad.
%
% Last update: 06/13/2015 (USA)
% Contact info: kalan019@umn.edu
%
% This program is free software; you can redistribute and/or modify it
% for non-commercial purposes. This program is distributed without any
% warranty.
%=====================================================================

clear

% Test matrix
%------------
B = fd3d(11, 10, 5);
n = size(B, 1);

% DD reordering
%--------------
ndom = 4;
[list, dptr, itrf, ~] = rdis1(B, ndom); 
[listg, ptrg] = loc2glob(list, dptr, itrf);
A = B(listg, listg);
m  = ptrg(ndom+1) - 1;
s  = n - m;
FH = A(1:m, m+1:n);
ET = A(m+1:n, 1:m);
B  = A(1:m, 1:m);
C  = A(m+1:n, m+1:n);

% Max Newton steps and tol
%-------------------------
max_newton_steps = 7;
tol              = 1e-10;

% Initial shift
%--------------
sigma = 0;

% Compute the eigenpair of $A$ which lies the closest to sigma
%-------------------------------------------------------------
[ lambda, y, u, resi_newton ] = Algorithm_3_1( A, B, C, FH, sigma, tol, max_newton_steps );




