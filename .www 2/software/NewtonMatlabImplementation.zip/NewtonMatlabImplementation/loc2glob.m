   function [listg, ptrg] = loc2glob(list,iptr,itrf)
%  function [listg, iptrg] = loc2glob(list,iptr,itrf)
%  get global  permutation from local permutation
% INPUT:
% list,iptr,itrf = description of domains as output by rdis1
% listg lists all interior nodes following by all interface
% nodes
% iptrg(i:ndom) = beginning of interior nodes for domain i
% iptrg(ndom+1:2*ndom+1) = beginning of interface nodes for
% domain i

ndom = length(itrf);
n = length(list);

listg  = zeros(n,1);
kl = 1;
ptrg = zeros(1,2*ndom+1);
ptrg(1) = kl;
%-------------------- interior points
for idom = 1:ndom
    for k=iptr(idom):itrf(idom)-1
        listg(kl) = list(k);
        kl = kl+1;
    end
    ptrg(idom+1) = kl;
end
%%-------------------- interface points
for idom = 1:ndom
    for k=itrf(idom):iptr(idom+1)-1;
        listg(kl) = list(k);
        kl = kl+1;
    end
    ptrg(ndom+idom+1) = kl;
end
