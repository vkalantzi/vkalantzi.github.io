      function [nlev,levels,list] =  BFS(A, init, mask, maskval)
%% function [nlev,levels,list] =  BFS(A, ninit, mask, maskval)
%% -----------------------------------------------------------------------
%%  finds the level-structure (breadth-init-search or CMK) ordering for a
%%  given sparse matrix. 
%% -------------------------parameters------------------------------------
%%  on entry:
%% ---------
%%      A      = matrix 
%% 
%%      mask   = array used to indicate whether or not a node should be 
%%      condidered in the graph. see maskval.
%%      mask is also used as a marker of  visited nodes. 
%%      
%%      maskval= consider node i only when:  mask(i) .eq. maskval 
%%      maskval must be .gt. 0. 
%%      thus, to consider all nodes, take mask(1:n) = 1. 
%%      maskval=1 (for example) 
%%      
%%      on return
%%      ---------
%%      list  = 'reverse permutation array'. Contains the labels of the nodes
%%      constituting all the levels found, from the first level to
%%      the last. 
%%      levels = pointer array for the level structure. If lev is a level
%%      number, and k1=levels(lev),k2=levels(lev+1)-1, then
%%      all the nodes of level number lev are:
%%      list(k1),list(k1+1),...,list(k2) 
%%      nlev   = number of levels found
%% -----------------------------------------------------------------------
  n = size(A,1); 
  nlev   = 0 ;
%%% CREATE LOCAL MASK - FROM MASK AND MASKVAL.. TO BE DONE,, 
  locmask = zeros(n,1);
  for i=1:n
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      iproc = mask(i) ;
      if (iproc > 0) 
         locmask(i) = iproc;
      else
         next = - iproc;
         while (next > 0) 
            iproc = mask(next) ;
            if (iproc == maskval) 
              locmask(i) = maskval;
            end 
            next = mask(next+1); 
         end   %% while 
      end   %% if 
    end   %% for 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%    initialize  
%% 
      count = 0; 
      newpt = 1; 
      lastlast = 0;
%% -----------------------------------------------------------------------; 
   while (newpt <n) 
%% start a new level 
     last = lastlast; 
     lastlast = lastlast+1 ; 
     list(lastlast) = init; 
     locmask(init) = 0; 
     count = count+1;
%% 
     while (last < lastlast) 
            nlev = nlev+1; 
%% gext next level -- 
            levels(nlev) = last + 1; 
            for nod = last+1:lastlast
                ir = list(nod); 
                [i,j,r] = find(A(ir,:));
                [i,j1,r] = find(A(:,ir));
                j = union(i',j) ; 
%%
                for k=1:length(j)
                    jcol = j(k) ;
%%                    fprintf(' ir = %d jcol = %d \n', ir, jcol)
		    if (locmask(jcol) == maskval) 
                        locmask(jcol) = 0;
			count = count+1; 
%%                        fprintf(' added %d \n', jcol) 
                        list(count) = jcol;
                    end
                 end
            end
	    last = lastlast;
            lastlast = count; 
       end  %% while 
%% 
%% restart 	    
%% seek a new point for next connected component.. 
         if (newpt >= n) 
               break; 
          end 
 
           while (locmask(newpt) ~= maskval  && newpt <n) 
                  newpt = newpt+1 ;
           end
           init = newpt; 
       end 
%% ----------------------------------------------------------------------- ; 
   levels(nlev+1) = lastlast+1 ; 
%% ----------------------------------------------------------------------- ; 
