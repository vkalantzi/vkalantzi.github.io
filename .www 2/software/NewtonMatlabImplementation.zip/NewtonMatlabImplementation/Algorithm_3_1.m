function [ sigma, eigvecs_btm, eigvecs_top, resi_norm ] = Algorithm_3_1( A, B, C, FH, sigma, tol, newton_steps )

% This routine computes the eigenvalue of A that lies the closest
% to sigma, by applying Newton's method on a function defined by 
% the smallest (in magnitude) eigenvalue of Sy=ly.
%
% Last update : 06 / 10 / 2015

s = length(C);
m = length(B);
u = orth(randn(s, 1));

for ii=1:newton_steps
%%-------------------- Matlab's eigs()
  [V, dv0] = eigs( C-sigma*speye(s) -FH'*( (B-sigma*speye(m)) \ FH ), 1, 'sm' );
  dv0 = diag(dv0);

%%-------------------- pick the wanted eigenvalue
  [~, jj] = min(abs(dv0));
  t  = dv0(jj);
  u = V(:,jj);
  u = u / norm(u);

%%-------------------- simple stopping test
  resi_norm(ii,1) = norm(A*[-(B - sigma*speye(m))\(FH*u);u] - sigma*[-(B - sigma*speye(m))\(FH*u); u]);
  if (resi_norm(ii,1) <= tol)
     eigvecs_btm = [u];
     eigvecs_top = [-(B - sigma*speye(m))\(FH*u)];
     break
  end

%%-------------------- get derivative and apply Newton's method
  eigvecs_btm = [u];
  eigvecs_top = [-(B - sigma*speye(m))\(FH*u)];
        
  % Derivative
  z     = (B - sigma*speye(m))\(FH*u);
  td    = z'*z;

  % Newton step
  sigma = sigma + ( t / (1+td) );

end



end




