     function [list, iptr, itrf, mask] = rdis1(A,ndom) 
%%   function [list, iptr, itrf, mask] = rdis1(A,ndom) 
%%   recursive graph bisection algorithm for partitioning.
%%   initial graph is cut in two - then each time, the largest set
%%   is cut in two until we reach desired number of domains.
%%   INPUT
%%      A         = matrix 
%%      ndom      = desired number of subgraphs
%%   OUTPUT 
%%     list   = list of points for each domain. 
%%     iptr   = pointer to beginning of each domain -- iptr(i)
%%              points to start of ith domain in list
%%     itrf   = points to start of interface points for each domain.
%%     mask   = array of size n -- mask(j)=subdomain number for node j. 
%%              [redondant information ] 
%% -----------------------------------------------------------------------;
      n = size(A,1) ; 
      idom = 1;
      siz(idom) = n;
      iptr(idom) = 1;
      mask(1:n) = 1 ;
%%
%%      domain loop;
%% 
      while (idom  < ndom) 
%% 
%%      select domain with largest siz;
%%
      maxsiz = siz(1);
      bigdom = 1;
      for j=2:idom
          if (siz(j) > maxsiz) 
            maxsiz = siz(j);
            bigdom = j;
         end
      end
%% 
%%    do a prphn node traversal.. 
%%
      maskval = bigdom; 
      init = iptr(bigdom) ; 
      [nlev, levels, map] = perphn(A,init,mask,maskval);
      iptr(bigdom) = map(1) ;
      iptr(idom+1) = map(levels(nlev+1)-1) ;
%%
%%   cut this domain in roughly two equal pieces 
%% 
      nextsiz = 0;
      wantsiz = maxsiz/2 ;
      idom = idom+1;
      for k = levels(nlev+1)-1:-1:1
          mask(map(k)) = idom;
          nextsiz = nextsiz+1 ; 
          if (nextsiz > wantsiz) 
             break; 
          end
      end
%%----------------------------------------------------------------------- 
     siz(idom) = nextsiz ; 
     siz(bigdom) = siz(bigdom) - nextsiz;
%%-----------------------------------------------------------------------
%%      new initial point = last point of previous domain;
%% 
     end %% while 
%%
%%      domains found -- build data structure ;
%%
%% addition: 
%% reorder each subdomain  == USES RCMK. - 
%% 
%% 
      ko = 1; 
      mapptr(1) = ko ;
      for idom = 1:ndom
          init = iptr(idom) ;
          [nlev, levels, temp] = perphn(A,init,mask,idom);  
          for k =levels(nlev+1)-1:-1:1
   	      map(ko) =  temp(k) ;
              ko = ko+1;
          end
	  mapptr(idom+1) = ko ;
      end
%% addition: 
%% identify interface vertices and list them at
%% end of each subdomain 
%%      
    iptr = zeros(ndom+1,1);
    last  = 0;  
    itrf = zeros(ndom,1);
    list = zeros(n,1);
    %%
    for idom  = 1:ndom
        first = last+1;
        last  = last+siz(idom)
        kf = first;
        kl = last;
        iptr(idom) = first;
        for ii=first:last 
            jnod = map(ii) ;
            [i,j,r]  = find(A(jnod,:));
            [i,j1,r] = find(A(:,jnod));
            j = union(i',j) ;
            interf = 0; 
            for k=1:length(j)
               jcol = j(k) ; 
               if (mask(jcol) ~= idom)  %%% interf, point
	          interf = 1;
                  break; 
               end
            end
            if (interf)  
                list(kl) = jnod;
                kl = kl-1;
            else
                list(kf) = jnod;
                kf = kf+1;
            end
            itrf(idom) = kl+1;
        end
    end
    iptr(ndom+1) = last+1;