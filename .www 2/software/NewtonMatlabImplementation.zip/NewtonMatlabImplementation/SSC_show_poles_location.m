% This script shows the location of poles within
% a given interval, as the number of subdomains
% varies.

clear
close 
format compact
format long 
%-------------------- generate matrix 
nx = 33;
ny = 23;
A0 = fd3d(nx,ny,1);
n  = size(A0,1);
% fixed pseudo-random... 
d = 217*[1:n] / 361;
d = 2*sin(3*d) - cos(5*pi*d);
d = d(:);
A0 = A0 + 0.5*spdiags(d, 0, n,n);

%-------------------- number of domains.
ndom = 2;

hold on;

for ii=1:4
%-------------------- reorder matrix
 [list, dptr, itrf, marker] = rdis1(A0, ndom); 
%-------------------- reorder so interior points are together etc.
 [listg, ptrg] = loc2glob(list,dptr,itrf);     
 A = A0(listg,listg);
%-------------------- get B block -- 
  m  = ptrg(ndom+1)-1;
  B  = A(1:m,1:m); 
  a = -0.3000003368849897;
  b = 0.500005088699965;
%--------------------
  D = eig(B);
  dB1 = D (D<b);
  dB = dB1 (dB1>a);
  t = 0.25;
  nev = length(dB);
  for j=1:nev
     plot([ii-t, ii+t], [dB(j), dB(j)],'o-','linewidth',3);
  end
  plot([ii ii], [a, b],'r--','linewidth',3);
  lab1 = sprintf('nev=%2d\n',nev);
  t = 0.3;
  text(ii-t,b+0.01,lab1,'fontsize',16) ;
  ndom = ndom*2;
end
axis([0.5, ii+0.8, a, b]);
lab3 =  sprintf('Spectral Distributions for B. Dim n=%3d',n);
%title(lab3,'fontsize',14);
set(gca,'xticklabel',{'p=2','p=4','p=8','p=16'});

print -depsc2 LapWithPert.eps







