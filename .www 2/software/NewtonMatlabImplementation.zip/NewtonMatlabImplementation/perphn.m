    function [nlev, levels, list]= perphn(A,init,mask,maskval)
%% -----------------------------------------------------------------------;
%%      finds a peripheral node and does a BFS search from it. ;
%% -----------------------------------------------------------------------;
%%      see routine  dblstr for description of parameters;
%%  input:
%% -------;
%%  ja, ia  = list pointer array for the adjacency graph;
%%  mask    = array used for masking nodes -- see maskval;
%%  maskval = value to be checked against for determing whether or;
%%            not a node is masked. If mask(k) .ne. maskval then;
%%            node k is not considered.;
%%  init    = init node in the pseudo-peripheral node algorithm.;
%%  
%%  output :
%% -------
%%  nlev    = number of levels in the final bfs traversal.;
%%  list    = 
%%  levels  =;
%% ----------------------------------------------------------------------- ;
   nlevp = -1 ;
   nlev  = 0;
   n = size(A,1); 
  
   while(nlev > nlevp) 
      [lev, levels, list] = bfs1(A, init, mask, maskval); 
%%%      fprintf(' nlev %d nlevp %d \n',nlev,nlevp) 
%%
      mindeg = n+1 ;
      for j=levels(lev):levels(lev+1)-1  
         nod = list(j) ;
         %% deg = maskdeg(A,nod,mask,maskval);
         deg = nnz(A(nod,:)); 
         if (deg < mindeg) 
             init = nod;
             mindeg = deg;
         end
      end
      nlevp = nlev;
      nlev  = lev;
    end
%% -----------------------------------------------------------------------;
      function [deg] = maskdeg (A, nod, mask,maskval) 
%% returns the masked degree of a node in a graph.. 
      deg = 0 ;
      [i,j,r] = find(A(nod,:));
      [i,j1,r] = find(A(:,nod));
      j = union(i',j) ; 
      for k=1:length(j)
          jcol = j(k) ;
          if (mask(jcol) == maskval) 
              deg = deg+1; 
          end
      end 
