clear
close

format compact
format long

nx = 15;
ny = 10;
nz = 5;
BB = fd3d(nx,ny,nz);
%BB = BB + spdiags(0.01*rand(n,1),0,n,n);
%load('nasa1824.mat');
%B = Problem.A;
n  = size(BB,1);

ndoms = [4;6;8;10;12];
a = 0.000;
b = 0.92;

for kk = 1:length(ndoms)

ndom = ndoms(kk);

[list, dptr, itrf, marker] = rdis1(BB, ndom);
[listg, ptrg] = loc2glob(list,dptr,itrf);
A = BB(listg,listg);

m = ptrg(ndom+1)-1;
s  = n-m;
FH = A(1:m,m+1:n);
ET = A(m+1:n,1:m);
B  = A(1:m,1:m);
C  = A(m+1:n,m+1:n);

dB  = eig(full(B));
dB2 = dB;
dB = dB(dB > a & dB < b);
dB = sort(dB);
nB = length(dB);
dA = eig(full(A));
dA = dA(dA >=a & dA <=b);
dA = sort(dA);
nA = length(dA);

npts = 50;
subs = [1, 8];
sigma_vals = linspace(a, b, npts);
sigma_vals = sort(sigma_vals);

if nB > 0
   pole     = dB(1);
else
   dB = inf;
   nB = 1;
   pole = dB;
end

store_eigvls = zeros(subs(2), npts);
store_derivs = zeros(subs(2), npts);
evaluations  = zeros(subs(2), 1);

poles_id = 1;


for j = 1:length(sigma_vals)

   sigma   = sigma_vals(j);
   S       = C - sigma*speye(s) - ET*((B-sigma*speye(m))\FH);
   [Y, dv] = eig(full(S));
   dv      = real(diag(dv));
   [dv,ind]= sort(dv);
   Y = Y(:,ind);

   
   % crossing a pole
   if (sigma > pole)
       poles_id = 1;
        
       for ii = 1:nB
          if (sigma > dB(ii))
             poles_id = poles_id + 1;
          end
       end
    end
    
    % part of the spectrum
    counter = 0;
    for ii  = poles_id:subs(2)
       counter = counter + 1;
       store_eigvls(ii,j) = dv(counter,1);
       evaluations(ii,1) = evaluations(ii,1) + 1;
    end

end


for ii = 1:subs(2)
   xx{ii} = store_eigvls(ii,1:evaluations(ii,1));
end


figure(kk)

FS = 'fontsize'; fs = 20;
FW = 'fontweight'; fw = 'bold';
LW = 'linewidth'; lw = 2;
MS = 'markersize'; ms = 7;
IN = 'interpreter'; in = 'latex';

hold on
plot(dA, zeros(nA,1), 'ro','linewidth',3)
%plot(dA(1), zeros(1,1), 'ro','linewidth',3)
plot([a, b], zeros(2,1), 'r--')

uplimit = 1.8;
lowlimit = -1.8;

for i = 1:nB
    plot([dB(i), dB(i)], [uplimit lowlimit], 'r--')
end

ylim([lowlimit uplimit]) 
for i = 1:subs(2)
   plot(sigma_vals(1:evaluations(i,1)), xx{i}, 'color', [0.0 0.0 0.8], 'linewidth', 2.5)
end
xlabel('\sigma')
ylabel('\mu_i(\sigma)')
title_str = sprintf('Eigs %d through %d in [%.1f %.1f]', subs(1), subs(2), a, b);
h=title(title_str);
set(h,'fontsize',18)

figureHandle = gcf;
set(findall(figureHandle,'type','text'),FS,fs,FW,fw,IN,in);
set(gca,FS,fs)


end




