 function A = fd3d(nx,ny,nz) 
%  function A = fd3d(nx,ny,nz) 
% NOTE nx and ny must be > 1 -- nz can be == 1.
%
% 5- or 7-point block-Diffusion/conv. matrix. with
%
tx = tridiag(2, -1, -1, nx) ;
ty = tridiag(2, -1, -1, ny) ;
tz = tridiag(2, -1, -1, nz) ;
A = kron(speye(ny,ny),tx) + kron(ty,speye(nx,nx)); 
if (nz > 1) 
     A = kron(speye(nz,nz),A) + kron(tz,speye(nx*ny,nx*ny)); 
end

